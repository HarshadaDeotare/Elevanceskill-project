import { useState, useRef, useEffect } from "react";
import {
  Play, Pause, Volume2, VolumeX, Maximize, SkipForward, SkipBack,
  Mic, MicOff, Video, VideoOff, PhoneOff, Monitor, Users, MessageSquare,
  Download, Crown, Check, CreditCard, Sun, Moon, Smartphone, Mail,
  ThumbsUp, ThumbsDown, Flag, Globe, AlertTriangle, Circle,
  ScreenShare, StopCircle, Bell, Languages, Shield, X,
} from "lucide-react";

type Tab = "watchparty" | "downloads" | "subscription" | "player" | "theme" | "comments";

const TABS: { id: Tab; label: string }[] = [
  { id: "watchparty", label: "Watch Party" },
  { id: "downloads", label: "Downloads" },
  { id: "subscription", label: "Subscription" },
  { id: "player", label: "Video Player" },
  { id: "theme", label: "Theme & Security" },
  { id: "comments", label: "Comments" },
];

/* ─── WATCH PARTY ─── */
const PARTICIPANTS = [
  { id: 1, name: "Harshada D.", initials: "HD", muted: false, camOff: false, host: true },
  { id: 2, name: "Rahul S.", initials: "RS", muted: true, camOff: false, host: false },
  { id: 3, name: "Priya K.", initials: "PK", muted: false, camOff: true, host: false },
  { id: 4, name: "Arjun M.", initials: "AM", muted: true, camOff: true, host: false },
];
const SEED_CHAT = [
  { id: 1, user: "Rahul S.", text: "This scene is absolutely insane 🔥", time: "9:41 PM" },
  { id: 2, user: "Priya K.", text: "Best episode of the season!", time: "9:42 PM" },
  { id: 3, user: "Harshada D.", text: "Did anyone catch the Easter egg at 12:34?", time: "9:43 PM" },
  { id: 4, user: "Arjun M.", text: "No way! Rewinding right now", time: "9:43 PM" },
];

function WatchParty() {
  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [recording, setRecording] = useState(false);
  const [showPeople, setShowPeople] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [msgs, setMsgs] = useState(SEED_CHAT);

  const send = () => {
    if (!chatInput.trim()) return;
    setMsgs((m) => [...m, { id: Date.now(), user: "You", text: chatInput, time: "now" }]);
    setChatInput("");
  };

  return (
    <div className="flex flex-col gap-4 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="heading text-2xl font-bold uppercase tracking-wide text-foreground">Watch Party — Breaking Bad S5E14</h2>
          <p className="text-muted-foreground text-sm mt-0.5">4 participants · Live now</p>
        </div>
        <div className="flex items-center gap-2">
          {recording && (
            <span className="flex items-center gap-1.5 text-xs font-medium text-red-400 bg-red-400/10 px-3 py-1.5 rounded-full border border-red-400/20">
              <Circle size={8} className="fill-red-400 animate-pulse" /> REC
            </span>
          )}
          <button onClick={() => setShowPeople(!showPeople)} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground bg-secondary px-3 py-2 rounded-lg border border-border transition-colors">
            <Users size={14} /> {PARTICIPANTS.length}
          </button>
        </div>
      </div>

      <div className="flex gap-4 flex-1 min-h-0">
        {/* Grid */}
        <div className="flex-1 flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-3">
            {PARTICIPANTS.map((p) => (
              <div key={p.id} className="relative rounded-xl overflow-hidden bg-secondary border border-border flex items-center justify-center" style={{ aspectRatio: "16/9" }}>
                <div className="flex flex-col items-center gap-2">
                  <div className="w-14 h-14 rounded-full bg-red-500/20 border-2 border-red-500/40 flex items-center justify-center text-xl font-bold text-red-400" style={{ fontFamily: "monospace" }}>{p.initials}</div>
                  {p.camOff && <span className="text-xs text-muted-foreground">Camera off</span>}
                </div>
                <div className="absolute bottom-2 left-2 flex items-center gap-1.5">
                  <span className="text-xs bg-black/70 text-white px-2 py-0.5 rounded-md">{p.name}</span>
                  {p.host && <span className="text-xs bg-red-600/80 text-white px-1.5 py-0.5 rounded-md">HOST</span>}
                </div>
                {p.muted && <div className="absolute top-2 right-2 bg-black/70 rounded-full p-1"><MicOff size={10} className="text-red-400" /></div>}
              </div>
            ))}
          </div>
          {sharing && (
            <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-3 flex items-center gap-3 text-sm">
              <ScreenShare size={16} className="text-red-400" />
              <span className="text-foreground">You are sharing your screen</span>
              <button onClick={() => setSharing(false)} className="ml-auto text-xs text-muted-foreground underline hover:text-foreground">Stop</button>
            </div>
          )}
          {/* Controls */}
          <div className="flex items-center justify-center gap-3 py-1">
            {[
              { icon: muted ? <MicOff size={18} /> : <Mic size={18} />, active: muted, action: () => setMuted(!muted) },
              { icon: camOff ? <VideoOff size={18} /> : <Video size={18} />, active: camOff, action: () => setCamOff(!camOff) },
              { icon: <ScreenShare size={18} />, active: sharing, action: () => setSharing(!sharing) },
              { icon: recording ? <StopCircle size={18} /> : <Circle size={18} />, active: recording, action: () => setRecording(!recording) },
            ].map((btn, i) => (
              <button key={i} onClick={btn.action} className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all ${btn.active ? "bg-red-500/20 border-red-500/40 text-red-400" : "bg-secondary border-border text-foreground hover:border-red-500/30"}`}>{btn.icon}</button>
            ))}
            <button className="w-12 h-12 rounded-full flex items-center justify-center bg-red-600 hover:bg-red-700 text-white border border-red-500 transition-all"><PhoneOff size={18} /></button>
          </div>
        </div>

        {/* Chat */}
        <div className="w-72 flex flex-col bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <MessageSquare size={14} className="text-red-400" />
            <span className="text-sm font-medium text-foreground">Party Chat</span>
          </div>
          <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-3" style={{ maxHeight: 300 }}>
            {msgs.map((m) => (
              <div key={m.id}>
                <div className="flex items-baseline gap-2">
                  <span className="text-xs font-semibold text-red-400">{m.user}</span>
                  <span className="text-xs text-muted-foreground">{m.time}</span>
                </div>
                <p className="text-sm text-foreground/90 mt-0.5">{m.text}</p>
              </div>
            ))}
          </div>
          <div className="p-3 border-t border-border flex gap-2">
            <input value={chatInput} onChange={(e) => setChatInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Say something..." className="flex-1 bg-secondary text-sm text-foreground placeholder:text-muted-foreground rounded-lg px-3 py-2 border border-border outline-none focus:border-red-500/50 transition-colors" />
            <button onClick={send} className="bg-red-600 text-white rounded-lg px-3 py-2 text-sm font-medium hover:bg-red-700 transition-colors">Send</button>
          </div>
        </div>

        {/* Participants panel */}
        {showPeople && (
          <div className="w-52 bg-card border border-border rounded-xl overflow-hidden flex flex-col">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">People</span>
              <button onClick={() => setShowPeople(false)}><X size={14} className="text-muted-foreground" /></button>
            </div>
            <div className="p-3 flex flex-col gap-2">
              {PARTICIPANTS.map((p) => (
                <div key={p.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-secondary transition-colors">
                  <div className="w-7 h-7 rounded-full bg-red-500/15 border border-red-500/25 flex items-center justify-center text-xs font-bold text-red-400">{p.initials}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{p.name}</p>
                    {p.host && <p className="text-xs text-red-400">Host</p>}
                  </div>
                  <div className="flex gap-1">
                    {p.muted && <MicOff size={10} className="text-red-400" />}
                    {p.camOff && <VideoOff size={10} className="text-muted-foreground" />}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── DOWNLOADS ─── */
const DL_HISTORY = [
  { id: 1, title: "Breaking Bad S5E14 — Ozymandias", size: "1.2 GB", date: "2026-07-22", plan: "Gold" },
  { id: 2, title: "The Dark Knight (2008)", size: "2.4 GB", date: "2026-07-21", plan: "Silver" },
  { id: 3, title: "Inception — Extended Cut", size: "3.1 GB", date: "2026-07-20", plan: "Gold" },
  { id: 4, title: "Interstellar (4K HDR)", size: "18.4 GB", date: "2026-07-19", plan: "Bronze" },
];
const PLAN_META: Record<string, { daily: number; monthly: number; color: string }> = {
  Free: { daily: 1, monthly: 5, color: "#6b7280" },
  Bronze: { daily: 3, monthly: 20, color: "#cd7f32" },
  Silver: { daily: 5, monthly: 50, color: "#a8a8b8" },
  Gold: { daily: 999, monthly: 999, color: "#fbbf24" },
};

function Downloads() {
  const [plan] = useState("Silver");
  const [todayCount, setTodayCount] = useState(2);
  const meta = PLAN_META[plan];
  const atLimit = todayCount >= meta.daily && meta.daily !== 999;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold uppercase tracking-wide text-foreground">Video Downloads</h2>
        <p className="text-muted-foreground text-sm mt-0.5">Offline content management</p>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Current Plan", value: plan, color: meta.color, sub: "" },
          { label: "Today", value: `${todayCount} / ${meta.daily === 999 ? "∞" : meta.daily}`, color: "#f0f0f3", sub: "", bar: meta.daily === 999 ? 0.2 : todayCount / meta.daily },
          { label: "This Month", value: `12 / ${meta.monthly === 999 ? "∞" : meta.monthly}`, color: "#f0f0f3", sub: "", bar: 0.24 },
        ].map((card) => (
          <div key={card.label} className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
            <p className="text-2xl font-bold" style={{ color: card.color }}>{card.value}</p>
            {"bar" in card && card.bar !== undefined && (
              <div className="mt-2 h-1.5 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-red-500 rounded-full transition-all" style={{ width: `${(card.bar as number) * 100}%` }} />
              </div>
            )}
          </div>
        ))}
      </div>
      {atLimit && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 flex items-center gap-3">
          <AlertTriangle size={15} className="text-yellow-400 shrink-0" />
          <p className="text-sm text-yellow-300">Daily limit reached for <strong>{plan}</strong> plan. Upgrade to download more.</p>
        </div>
      )}
      <div className="flex flex-col gap-2">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-1">Download History</h3>
        {DL_HISTORY.map((d) => (
          <div key={d.id} className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-red-500/20 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center">
              <Download size={16} className="text-red-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{d.title}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{d.date} · {d.size}</p>
            </div>
            <span className="text-xs px-2 py-0.5 rounded-full border font-medium" style={{ color: PLAN_META[d.plan].color, borderColor: `${PLAN_META[d.plan].color}40`, backgroundColor: `${PLAN_META[d.plan].color}12` }}>{d.plan}</span>
            <span className="text-xs text-green-400 bg-green-400/10 border border-green-400/20 px-2 py-0.5 rounded-full">Done</span>
          </div>
        ))}
      </div>
      <button
        onClick={() => !atLimit && setTodayCount((n) => n + 1)}
        className={`self-start flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium text-sm transition-all ${atLimit ? "bg-secondary text-muted-foreground cursor-not-allowed border border-border" : "bg-red-600 text-white hover:bg-red-700"}`}
      >
        <Download size={14} /> {atLimit ? "Limit Reached — Upgrade Plan" : "Download New Video"}
      </button>
    </div>
  );
}

/* ─── SUBSCRIPTION ─── */
const PLANS = [
  { id: "free", name: "Free", price: 0, color: "#6b7280", features: ["5 videos/day", "720p quality", "1 download/day", "Ads included"], missing: ["HD/4K", "Watch parties", "Ad-free"] },
  { id: "bronze", name: "Bronze", price: 99, color: "#cd7f32", features: ["Unlimited videos", "1080p HD", "3 downloads/day", "Watch parties (4p)"], missing: ["4K streaming", "Ad-free"] },
  { id: "silver", name: "Silver", price: 249, color: "#a8a8b8", features: ["Unlimited videos", "4K quality", "5 downloads/day", "Ad-free", "Watch parties (8p)"], missing: ["Unlimited downloads"] },
  { id: "gold", name: "Gold", price: 499, color: "#fbbf24", features: ["Unlimited everything", "4K + HDR", "Unlimited downloads", "Ad-free", "Watch parties (20p)", "Priority support"], missing: [] },
];

function Subscription() {
  const [current, setCurrent] = useState("silver");
  const [modal, setModal] = useState<typeof PLANS[0] | null>(null);
  const [paid, setPaid] = useState(false);
  const [txnId] = useState(() => "TXN" + Math.random().toString(36).slice(2, 10).toUpperCase());

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold uppercase tracking-wide text-foreground">Subscription Plans</h2>
        <p className="text-muted-foreground text-sm mt-0.5">Upgrade via Razorpay secure payment</p>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {PLANS.map((p) => (
          <div key={p.id} className={`relative flex flex-col rounded-2xl border p-5 transition-all ${p.id === current ? "border-red-500/50 bg-red-500/5" : "border-border bg-card"}`}>
            {p.id === "gold" && <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-500 text-black text-xs font-bold px-3 py-0.5 rounded-full">BEST VALUE</div>}
            <p className="text-lg font-bold uppercase tracking-wider mb-1" style={{ color: p.color }}>{p.name}</p>
            <p className="text-3xl font-bold text-foreground mb-4">{p.price === 0 ? "Free" : `₹${p.price}`}<span className="text-sm font-normal text-muted-foreground">{p.price > 0 ? "/mo" : ""}</span></p>
            <div className="flex-1 flex flex-col gap-1.5">
              {p.features.map((f) => <div key={f} className="flex items-start gap-2 text-xs text-foreground/80"><Check size={11} className="text-green-400 mt-0.5 shrink-0" />{f}</div>)}
              {p.missing.map((f) => <div key={f} className="flex items-start gap-2 text-xs text-muted-foreground line-through"><X size={11} className="mt-0.5 shrink-0" />{f}</div>)}
            </div>
            <button
              onClick={() => { if (p.id !== current) { setModal(p); setPaid(false); } }}
              className="mt-5 w-full py-2 rounded-xl text-sm font-semibold transition-all text-white"
              style={{ backgroundColor: p.id === current ? "#2a2a35" : p.color, cursor: p.id === current ? "default" : "pointer" }}
            >
              {p.id === current ? "Current Plan" : p.price === 0 ? "Downgrade" : "Upgrade"}
            </button>
          </div>
        ))}
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6">
            {paid ? (
              <div className="flex flex-col items-center gap-4 py-4 text-center">
                <div className="w-14 h-14 rounded-full bg-green-500/20 border-2 border-green-500/40 flex items-center justify-center"><Check size={26} className="text-green-400" /></div>
                <h3 className="text-xl font-bold text-foreground">Payment Successful!</h3>
                <p className="text-sm text-muted-foreground">You are now on the <strong style={{ color: modal.color }}>{modal.name}</strong> plan. Confirmation sent to your email.</p>
                <div className="w-full bg-secondary rounded-xl p-4 text-xs text-left space-y-1" style={{ fontFamily: "monospace" }}>
                  <p>Transaction: <span className="text-foreground">{txnId}</span></p>
                  <p>Amount: <span className="text-foreground">₹{modal.price}.00</span></p>
                  <p>Date: <span className="text-foreground">2026-07-22</span></p>
                  <p>Plan: <span style={{ color: modal.color }}>{modal.name}</span></p>
                </div>
                <button onClick={() => { setCurrent(modal.id); setModal(null); }} className="w-full bg-red-600 text-white py-2.5 rounded-xl font-semibold text-sm hover:bg-red-700 transition-colors">Done</button>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between mb-5">
                  <h3 className="text-lg font-bold text-foreground">Upgrade to {modal.name}</h3>
                  <button onClick={() => setModal(null)}><X size={18} className="text-muted-foreground" /></button>
                </div>
                <div className="bg-secondary rounded-xl p-4 mb-5 flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">{modal.name} / Monthly</span>
                  <span className="text-xl font-bold" style={{ color: modal.color }}>₹{modal.price}</span>
                </div>
                <div className="flex flex-col gap-3 mb-5">
                  <input placeholder="Card number" className="bg-input-background text-foreground text-sm rounded-lg px-4 py-2.5 border border-border outline-none focus:border-red-500/50 w-full transition-colors" />
                  <div className="grid grid-cols-2 gap-3">
                    <input placeholder="MM / YY" className="bg-input-background text-foreground text-sm rounded-lg px-4 py-2.5 border border-border outline-none focus:border-red-500/50 transition-colors" />
                    <input placeholder="CVV" className="bg-input-background text-foreground text-sm rounded-lg px-4 py-2.5 border border-border outline-none focus:border-red-500/50 transition-colors" />
                  </div>
                </div>
                <button onClick={() => setPaid(true)} className="w-full bg-red-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-red-700 transition-colors flex items-center justify-center gap-2">
                  <CreditCard size={15} /> Pay ₹{modal.price} via Razorpay
                </button>
                <p className="text-xs text-muted-foreground text-center mt-3">Secured by Razorpay · Test mode</p>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── VIDEO PLAYER ─── */
function VideoPlayer() {
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(80);
  const [progress, setProgress] = useState(34);
  const [showVol, setShowVol] = useState(false);
  const [gesture, setGesture] = useState<"fwd" | "bwd" | null>(null);
  const [showNext, setShowNext] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (playing) {
      timerRef.current = setInterval(() => setProgress((p) => { if (p >= 100) { setPlaying(false); setShowNext(true); return 100; } return p + 0.25; }), 100);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [playing]);

  const seek = (dir: "fwd" | "bwd") => {
    setProgress((p) => Math.min(100, Math.max(0, p + (dir === "fwd" ? 4.5 : -4.5))));
    setGesture(dir);
    setTimeout(() => setGesture(null), 700);
  };

  const fmt = (pct: number) => { const s = Math.floor((pct / 100) * 3720); return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`; };

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold uppercase tracking-wide text-foreground">Custom Video Player</h2>
        <p className="text-muted-foreground text-sm mt-0.5">Full controls · Gesture support · Next-video overlay</p>
      </div>
      <div className="relative rounded-2xl overflow-hidden bg-black border border-border select-none" style={{ aspectRatio: "16/9", maxHeight: 400 }}>
        <img src="https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=675&fit=crop&auto=format" alt="Video scene" className="w-full h-full object-cover opacity-75" />

        {gesture && (
          <div className={`absolute top-1/2 -translate-y-1/2 ${gesture === "fwd" ? "right-16" : "left-16"} flex flex-col items-center gap-1 pointer-events-none`}>
            <div className="bg-white/20 rounded-full p-3 backdrop-blur-sm">{gesture === "fwd" ? <SkipForward size={26} className="text-white" /> : <SkipBack size={26} className="text-white" />}</div>
            <span className="text-white text-xs font-semibold bg-black/50 px-2 py-0.5 rounded-full">{gesture === "fwd" ? "+10s" : "-10s"}</span>
          </div>
        )}

        <button className="absolute inset-y-0 left-0 w-1/3" onClick={() => seek("bwd")} />
        <button className="absolute inset-y-0 right-0 w-1/3" onClick={() => seek("fwd")} />

        {!playing && progress === 34 && !showNext && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <button className="w-16 h-16 rounded-full bg-red-600/90 hover:bg-red-600 flex items-center justify-center shadow-xl pointer-events-auto transition-all" onClick={() => setPlaying(true)}>
              <Play size={26} className="text-white ml-1" />
            </button>
          </div>
        )}

        {showNext && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
            <div className="text-center">
              <p className="text-white/50 text-sm mb-1">Up next</p>
              <p className="text-white text-xl font-bold mb-4">Inception (2010)</p>
              <button onClick={() => { setProgress(0); setShowNext(false); }} className="bg-red-600 text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-red-700 transition-colors">Play Now</button>
            </div>
          </div>
        )}

        {/* Bottom controls */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent px-4 pb-3 pt-10">
          <div className="relative h-1.5 bg-white/20 rounded-full mb-3 cursor-pointer group" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); setProgress(((e.clientX - r.left) / r.width) * 100); }}>
            <div className="h-full bg-red-500 rounded-full relative" style={{ width: `${progress}%` }}>
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow" />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => setPlaying(!playing)} className="text-white hover:text-red-400 transition-colors">{playing ? <Pause size={20} /> : <Play size={20} />}</button>
            <button onClick={() => seek("bwd")} className="text-white/70 hover:text-white transition-colors"><SkipBack size={17} /></button>
            <button onClick={() => seek("fwd")} className="text-white/70 hover:text-white transition-colors"><SkipForward size={17} /></button>
            <div className="relative flex items-center gap-2" onMouseEnter={() => setShowVol(true)} onMouseLeave={() => setShowVol(false)}>
              <button onClick={() => setMuted(!muted)} className="text-white/70 hover:text-white transition-colors">{muted ? <VolumeX size={17} /> : <Volume2 size={17} />}</button>
              {showVol && <input type="range" min={0} max={100} value={muted ? 0 : volume} onChange={(e) => { setVolume(+e.target.value); setMuted(false); }} className="w-20 accent-red-500" />}
            </div>
            <span className="text-white/60 text-xs" style={{ fontFamily: "monospace" }}>{fmt(progress)} / {fmt(100)}</span>
            <div className="flex-1" />
            <button className="text-white/70 hover:text-white transition-colors"><Maximize size={17} /></button>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-3 text-xs text-muted-foreground bg-card border border-border rounded-xl px-4 py-3">
        <span className="text-red-400">📱</span>
        <span>Mobile gesture: double-tap left to rewind 10s · double-tap right to skip 10s</span>
      </div>
    </div>
  );
}

/* ─── THEME & SECURITY ─── */
function ThemeSecurity() {
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [verified, setVerified] = useState(false);
  const inputRefs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];
  const hour = new Date().getHours();
  const autoTheme = hour >= 10 && hour < 12 ? "light" : "dark";

  const handleOtpInput = (i: number, v: string) => {
    if (!/^\d?$/.test(v)) return;
    const next = [...otp]; next[i] = v; setOtp(next);
    if (v && i < 5) inputRefs[i + 1].current?.focus();
  };

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold uppercase tracking-wide text-foreground">Theme & Security</h2>
        <p className="text-muted-foreground text-sm mt-0.5">Smart theming · OTP verification · Location detection</p>
      </div>
      <div className="grid grid-cols-2 gap-6">
        {/* Theme */}
        <div className="bg-card border border-border rounded-2xl p-5 flex flex-col gap-5">
          <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-lg bg-red-500/15 flex items-center justify-center"><Sun size={15} className="text-red-400" /></div><h3 className="font-semibold text-foreground">Appearance</h3></div>
          <div className="bg-secondary rounded-xl p-4 text-sm">
            <p className="text-xs text-muted-foreground mb-1">Auto-theme rule</p>
            <p className="text-foreground font-medium">{autoTheme === "light" ? "☀️ Light mode (10 AM – 12 PM IST)" : "🌙 Dark mode (all other times)"}</p>
            <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: "monospace" }}>Now: {new Date().toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata" })} IST</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-2">Manual override</p>
            <div className="flex gap-3">
              {(["light", "dark"] as const).map((t) => (
                <button key={t} onClick={() => setTheme(t)} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-sm font-medium transition-all ${theme === t ? "bg-red-500/10 border-red-500/40 text-red-400" : "border-border text-muted-foreground hover:text-foreground"}`}>
                  {t === "light" ? <Sun size={13} /> : <Moon size={13} />} {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between bg-secondary rounded-xl px-4 py-3">
            <span className="text-sm text-foreground">Save to profile</span>
            <div className="w-10 h-5 rounded-full bg-red-600 relative"><span className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow" /></div>
          </div>
        </div>

        {/* Security */}
        <div className="bg-card border border-border rounded-2xl p-5 flex flex-col gap-4">
          <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-lg bg-red-500/15 flex items-center justify-center"><Shield size={15} className="text-red-400" /></div><h3 className="font-semibold text-foreground">Login Security</h3></div>
          <div className="bg-secondary rounded-xl p-4">
            <p className="text-xs text-muted-foreground mb-0.5">Last verified login</p>
            <p className="text-sm text-foreground font-medium">Mumbai, Maharashtra · Chrome / Windows</p>
            <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: "monospace" }}>2026-07-22 · 09:41 IST</p>
          </div>
          {verified ? (
            <div className="bg-green-500/10 border border-green-500/25 rounded-xl p-4 flex items-center gap-3"><Check size={14} className="text-green-400 shrink-0" /><p className="text-sm text-green-300 font-medium">New device verified successfully</p></div>
          ) : (
            <div className="bg-yellow-500/10 border border-yellow-500/25 rounded-xl p-4">
              <div className="flex items-start gap-3 mb-3"><AlertTriangle size={14} className="text-yellow-400 shrink-0 mt-0.5" /><div><p className="text-sm text-yellow-300 font-medium">New location detected</p><p className="text-xs text-yellow-400/70 mt-0.5">Pune, Maharashtra · Firefox / macOS</p></div></div>
              <button onClick={() => setShowOtp(true)} className="w-full bg-yellow-500/15 hover:bg-yellow-500/25 border border-yellow-500/30 text-yellow-300 text-sm py-2 rounded-xl transition-colors font-medium">Verify via OTP</button>
            </div>
          )}
          <div className="flex flex-col gap-2">
            {[{ icon: <Mail size={12} />, label: "OTP via Email", sub: "har****@gmail.com" }, { icon: <Smartphone size={12} />, label: "OTP via SMS", sub: "+91 98765 *****" }].map((o) => (
              <div key={o.label} className="flex items-center gap-3 bg-secondary px-4 py-3 rounded-xl">
                <span className="text-red-400">{o.icon}</span>
                <div className="flex-1"><p className="text-xs font-medium text-foreground">{o.label}</p><p className="text-xs text-muted-foreground">{o.sub}</p></div>
                <Check size={11} className="text-green-400" />
              </div>
            ))}
          </div>
        </div>
      </div>

      {showOtp && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-2"><h3 className="text-lg font-bold text-foreground">OTP Verification</h3><button onClick={() => setShowOtp(false)}><X size={17} className="text-muted-foreground" /></button></div>
            <p className="text-sm text-muted-foreground mb-6">Enter the 6-digit code sent to har****@gmail.com</p>
            <div className="flex gap-2 justify-center mb-6">
              {otp.map((v, i) => (
                <input key={i} ref={inputRefs[i]} maxLength={1} value={v} onChange={(e) => handleOtpInput(i, e.target.value)} className="w-11 h-12 text-center text-lg font-bold text-foreground bg-secondary border border-border rounded-xl outline-none focus:border-red-500 transition-colors" style={{ fontFamily: "monospace" }} />
              ))}
            </div>
            <button onClick={() => { if (otp.join("").length === 6) { setVerified(true); setShowOtp(false); } }} className="w-full bg-red-600 text-white py-2.5 rounded-xl font-semibold text-sm hover:bg-red-700 transition-colors">Verify</button>
            <p className="text-xs text-muted-foreground text-center mt-3">Resend OTP in 30s</p>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── COMMENTS ─── */
const ABUSIVE_WORDS = ["spam", "idiot", "hate", "stupid", "scam", "abuse"];
const LANGS = ["English", "Hindi", "Marathi", "Spanish", "French", "German"];
const SEED_COMMENTS = [
  { id: 1, user: "Rahul S.", text: "This video is absolutely mind-blowing! Best content on this platform.", lang: "English", time: "2h ago", likes: 42, dislikes: 1, reported: false, flagged: false, translatedText: "" },
  { id: 2, user: "Priya K.", text: "यह वीडियो बहुत अच्छा है! मुझे बहुत पसंद आया।", lang: "Hindi", time: "1h ago", likes: 28, dislikes: 0, reported: false, flagged: false, translatedText: "This video is very good! I liked it very much." },
  { id: 3, user: "Arjun M.", text: "Great explanation! Could you make a part 2?", lang: "English", time: "45m ago", likes: 15, dislikes: 2, reported: false, flagged: false, translatedText: "" },
  { id: 4, user: "Anonymous", text: "buy followers now click here!!!!!", lang: "English", time: "30m ago", likes: 0, dislikes: 18, reported: true, flagged: true, translatedText: "" },
];

function Comments() {
  const [comments, setComments] = useState(SEED_COMMENTS.map((c) => ({ ...c, showTranslated: false })));
  const [input, setInput] = useState("");
  const [lang, setLang] = useState("English");
  const [warning, setWarning] = useState("");

  const post = () => {
    const lower = input.toLowerCase();
    for (const w of ABUSIVE_WORDS) { if (lower.includes(w)) { setWarning(`Blocked: contains prohibited word "${w}"`); return; } }
    if (/^[^a-zA-Z0-9ऀ-ॿ]{5,}$/.test(input.trim())) { setWarning("Blocked: repeated special characters detected."); return; }
    if (input.trim().length < 3) return;
    setWarning("");
    setComments((prev) => [...prev, { id: Date.now(), user: "You", text: input, lang, time: "just now", likes: 0, dislikes: 0, reported: false, flagged: false, translatedText: "", showTranslated: false }]);
    setInput("");
  };

  const update = (id: number, patch: Partial<typeof comments[0]>) => setComments((prev) => prev.map((c) => c.id === id ? { ...c, ...patch } : c));

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h2 className="text-2xl font-bold uppercase tracking-wide text-foreground">Comment Section</h2>
        <p className="text-muted-foreground text-sm mt-0.5">Multilingual · Moderated · Translatable</p>
      </div>

      {/* Post */}
      <div className="bg-card border border-border rounded-2xl p-4 flex flex-col gap-3">
        <textarea value={input} onChange={(e) => { setInput(e.target.value); setWarning(""); }} placeholder="Write a comment..." rows={2} className="w-full bg-secondary text-sm text-foreground placeholder:text-muted-foreground rounded-xl px-4 py-3 border border-border outline-none focus:border-red-500/50 transition-colors resize-none" />
        <div className="flex items-center gap-3">
          <Globe size={13} className="text-muted-foreground" />
          <select value={lang} onChange={(e) => setLang(e.target.value)} className="bg-secondary text-foreground text-xs border border-border rounded-lg px-3 py-1.5 outline-none">
            {LANGS.map((l) => <option key={l}>{l}</option>)}
          </select>
          <div className="flex-1" />
          <button onClick={post} className="bg-red-600 text-white text-sm font-semibold px-5 py-2 rounded-xl hover:bg-red-700 transition-colors">Post</button>
        </div>
        {warning && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-2.5 text-sm text-red-400">
            <AlertTriangle size={12} /> {warning}
          </div>
        )}
      </div>

      {/* Comments */}
      <div className="flex flex-col gap-3">
        {comments.map((c) => (
          <div key={c.id} className={`bg-card border rounded-xl p-4 transition-all ${c.flagged ? "border-yellow-500/30 bg-yellow-500/5" : "border-border"}`}>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-red-500/15 border border-red-500/25 flex items-center justify-center text-xs font-bold text-red-400 shrink-0">{c.user.slice(0, 2).toUpperCase()}</div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span className="text-xs font-semibold text-foreground">{c.user}</span>
                  <span className="text-xs text-muted-foreground">{c.time}</span>
                  <span className="text-xs text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">{c.lang}</span>
                  {c.flagged && <span className="text-xs text-yellow-400 bg-yellow-400/10 border border-yellow-400/20 px-2 py-0.5 rounded-full flex items-center gap-1"><Flag size={8} /> Flagged for review</span>}
                </div>
                <p className="text-sm text-foreground/90">{c.showTranslated && c.translatedText ? c.translatedText : c.text}</p>
                {c.showTranslated && c.translatedText && <p className="text-xs text-muted-foreground mt-1 italic">Translated from {c.lang}</p>}
                <div className="flex items-center gap-3 mt-2">
                  <button onClick={() => update(c.id, { likes: c.likes + 1 })} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-green-400 transition-colors"><ThumbsUp size={11} /> {c.likes}</button>
                  <button onClick={() => update(c.id, { dislikes: c.dislikes + 1 })} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-red-400 transition-colors"><ThumbsDown size={11} /> {c.dislikes}</button>
                  {c.translatedText && (
                    <button onClick={() => update(c.id, { showTranslated: !c.showTranslated })} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-red-400 transition-colors"><Languages size={11} /> {c.showTranslated ? "Original" : "Translate"}</button>
                  )}
                  {!c.reported ? (
                    <button onClick={() => update(c.id, { reported: true, flagged: true })} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-yellow-400 transition-colors ml-auto"><Flag size={11} /> Report</button>
                  ) : (
                    <span className="flex items-center gap-1 text-xs text-yellow-400/60 ml-auto"><Flag size={11} /> Reported</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── ROOT ─── */
export default function App() {
  const [tab, setTab] = useState<Tab>("watchparty");

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "Inter, sans-serif" }}>
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center gap-4">
          <div className="flex items-center gap-2 mr-4 shrink-0">
            <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center">
              <Play size={12} className="text-white fill-white ml-0.5" />
            </div>
            <span className="font-bold text-foreground text-base tracking-widest uppercase">YourTube 2.0</span>
          </div>
          <nav className="flex gap-1 overflow-x-auto flex-1">
            {TABS.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)} className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${tab === t.id ? "bg-red-500/15 text-red-400 border border-red-500/30" : "text-muted-foreground hover:text-foreground hover:bg-secondary"}`}>
                {t.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2 ml-2 shrink-0">
            <button className="w-8 h-8 rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"><Bell size={14} /></button>
            <div className="w-8 h-8 rounded-full bg-red-500/20 border border-red-500/30 flex items-center justify-center text-xs font-bold text-red-400">HD</div>
          </div>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-6 py-8">
        {tab === "watchparty" && <WatchParty />}
        {tab === "downloads" && <Downloads />}
        {tab === "subscription" && <Subscription />}
        {tab === "player" && <VideoPlayer />}
        {tab === "theme" && <ThemeSecurity />}
        {tab === "comments" && <Comments />}
      </main>
    </div>
  );
}
