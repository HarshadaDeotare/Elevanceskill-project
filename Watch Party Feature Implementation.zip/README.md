
  # Watch Party Feature Implementation

  This is a code bundle for Watch Party Feature Implementation. The original project is available at https://www.figma.com/design/ZvVLT3rDxIMV1gmowKfv8z/Watch-Party-Feature-Implementation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  